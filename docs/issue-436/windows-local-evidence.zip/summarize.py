import json, pathlib, hashlib, zipfile, datetime
root = pathlib.Path(__file__).parent
summaries = []
for directory in sorted(p for p in root.iterdir() if p.is_dir()):
    target = directory / 'results.json'
    if not target.exists():
        if (directory / 'manifest.json').exists():
            summaries.append(dict(directory=directory.name, status='INVALID_INCOMPLETE_EVIDENCE', reason='No results.json; interrupted run is NOT_TESTED; do not infer exit'))
        continue
    report = json.loads(target.read_text(encoding='utf-8-sig'))
    item = dict(directory=directory.name, status=report.get('status'), sourceHead=report.get('testedHead'), start=report.get('startedAt'), end=report.get('finishedAt'))
    manifest = directory / 'manifest.json'
    if manifest.exists():
        try:
            data = json.loads(manifest.read_text(encoding='utf-8-sig'))
            item.update(exit=data.get('exit'), diagnosticSha256=data.get('diagnosticSha256'), freeMemory=data.get('freeMemory'))
        except Exception as exc: item['manifestError'] = str(exc)
    item['cases'] = [dict(browser=c.get('browser'), status=c.get('status'), completed=c.get('evidence',{}).get('execution',{}).get('completed'), error=c.get('error'), repeatedConflict=c.get('repeatedConflict',{}).get('status'), explicitResolution=c.get('explicitResolution',{}).get('status')) for c in report.get('cases',[])]
    timeline = directory / 'timeline.jsonl'
    if timeline.exists():
        rows = [json.loads(line) for line in timeline.read_text(encoding='utf-8').splitlines() if line]
        item['snapshots'] = [r for r in rows if r['event'].startswith('snapshot')]
        item['milestones'] = [r for r in rows if r['event'] in ['T0:launch:start','T0:launch:end','T1:context:start','T1:context:end','T2:page:start','T2:page:end','goto:start','goto:end','reload:start','reload:end','close:start','close:end','openApp:error','appReady:error'] or r['event']=='page:mark' and (r['mark']['event'].startswith(('T5:','T6:','T7:','T9:','await:')) or r['mark']['event'] in ['DOMContentLoaded','load','guard'])]
    summaries.append(item)
(root / 'local-summary.json').write_text(json.dumps(summaries, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
for s in summaries:
    print(json.dumps({k:v for k,v in s.items() if k not in ['snapshots','milestones']}, ensure_ascii=False))
