import pathlib, json, hashlib, zipfile, datetime, shutil
root = pathlib.Path(__file__).parent
dest = root.parents[1] / 'docs' / 'issue-436'
sha = lambda data: hashlib.sha256(data).hexdigest()
records, intervalsets = [], []
for name in ['independent-review.md','report.md','protected-refs-audit.json']:
    shutil.copyfile(dest/name,root/name)
for file in sorted(root.rglob('timeline.jsonl')):
    if 'source' in file.parts: continue
    raw = file.read_bytes()
    if b'\x00' in raw:
        intervalsets.append(dict(path=file.relative_to(root).as_posix(), state='INVALID_EVIDENCE', reason='NUL bytes; no fabricated intervals'))
        continue
    rows = [json.loads(line) for line in raw.decode('utf-8').splitlines() if line]
    spans, pending, marks = [], {}, []
    for row in rows:
        event, page = row['event'], row.get('page')
        for end in [':start', ':end', ':error']:
            if event.endswith(end):
                label = event[:-len(end)]
                if label not in ['T0:launch','T1:context','T2:page','goto','reload','openApp','appReady','close']: break
                key = (label, None if label == 'T2:page' else page)
                if end == ':start': pending[key] = row
                elif key in pending:
                    start = pending.pop(key)
                    spans.append(dict(clock='node-receipt-monotonic', stage=label, page=page, startMs=start['elapsedMs'], endMs=row['elapsedMs'], elapsedMs=row['elapsedMs']-start['elapsedMs'], exception=row.get('error'), status='ERROR' if end==':error' else 'COMPLETE'))
                break
        if event=='page:mark': marks.append(dict(page=page, **row['mark']))
    for (label,page), start in pending.items(): spans.append(dict(clock='node-receipt-monotonic', stage=label, page=page, startMs=start['elapsedMs'], endMs=None, status='END_NOT_OBSERVED'))
    browsers, waits = [], {}
    for mark in marks:
        event, page, origin, ms = mark['event'], mark['page'], mark['timeOrigin'], mark['pageMs']
        if event.startswith('await:start:'): waits[(page,origin,event[12:])] = mark
        elif event.startswith('await:end:'):
            label=event[10:]; start=waits.pop((page,origin,label),None)
            if start: browsers.append(dict(clock='browser-performance', page=page,timeOrigin=origin,stage=label,startMs=start['pageMs'],endMs=ms,elapsedMs=ms-start['pageMs'],status='COMPLETE'))
    for (page,origin,label), start in waits.items(): browsers.append(dict(clock='browser-performance',page=page,timeOrigin=origin,stage=label,startMs=start['pageMs'],endMs=None,status='END_NOT_OBSERVED'))
    intervalsets.append(dict(path=file.relative_to(root).as_posix(), nodeSpans=spans,browserAwaitSpans=browsers,
        browserEvents=[m for m in marks if not m['event'].startswith('await:')],
        snapshots=[r for r in rows if r['event'].startswith('snapshot')],
        limitations=['snapshot receipt can be later than timeout; original raw retained','T11 complete save/recovery outcomes in results.json; action start/end not separately timestamped']))
(dest/'startup-intervals.json').write_text(json.dumps(intervalsets,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

files=[]
for file in sorted(root.rglob('*')):
    if not file.is_file(): continue
    rel=file.relative_to(root)
    if 'source' in rel.parts or file.name=='source.tar' or rel.parts[0] in ['ci-linux','ci-windows'] or file.name in ['ci-linux-artifact.zip','ci-windows-artifact.zip']: continue
    files.append((file,rel.as_posix()))
inventory=[dict(path=name,bytes=file.stat().st_size,sha256=sha(file.read_bytes())) for file,name in files]
local=dest/'windows-local-evidence.zip'
with zipfile.ZipFile(local,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for file,name in files: z.write(file,name)
    z.writestr('SHA256SUMS.json',json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
archives=[dict(path=local.name,bytes=local.stat().st_size,sha256=sha(local.read_bytes()),files=inventory,
    retention='Repository copy: no automatic expiration; retained until repository content is removed. Local temporary directories have no guaranteed retention.')]
api=json.loads((root/'ci-artifacts-api.json').read_text(encoding='utf-8-sig'))
for label in ['linux','windows']:
    src=root/f'ci-{label}-artifact.zip'; target=dest/f'ci-{label}-evidence.zip'; shutil.copyfile(src,target)
    digest=sha(target.read_bytes())
    artifact=next(a for a in api['artifacts'] if a['digest']=='sha256:'+digest)
    with zipfile.ZipFile(target) as z:
        items=[dict(path=i.filename,bytes=i.file_size,sha256=sha(z.read(i))) for i in z.infolist() if not i.is_dir()]
    archives.append(dict(path=target.name,bytes=target.stat().st_size,sha256=digest,files=items,
        githubArtifact=artifact,retention='Original GitHub artifact expires as stated; repository copy has no automatic expiration.'))
index=dict(createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceFixed='478d8b3ea59b242e4ddd5cc82e12b44169223047',sourceLegacy='8f35ca25001ffa031abfd304dd2a5e9a3d9197dd',ciRunnerHead='9c344ede39696b0ad0b9696005c6d1c82ca902a4',ciRun=42614097846,archives=archives,
    documents=[dict(path=name,bytes=(dest/name).stat().st_size,sha256=sha((dest/name).read_bytes())) for name in ['report.md','protocol.md','independent-review.md','protected-refs-audit.json','startup-intervals.json']],
    diagnosticImplementations={'initialLocalLF':'3c3c4e0dec8cf5b846ef37d9c50ecfbf90495fd926e64991e15a2be0812192e0','currentLocalAndLinuxLF':'a8995f1a26b219fff8c1587648c28e3178641c4631ca703a25a551a7e685a9b4','currentWindowsCICRLF':'631f63813a8461c970736e3220b27364506cc719c9783ebd06f480bd9242ba0d','difference':'Windows CI checkout CRLF conversion independently reproduced; all source archives retain verified git blob bytes.'},
    localDirectory=str(root.resolve()),safety={'J2/U-C':'UNKNOWN','conditionU':'NOT_RUN','executionAuthorization':'NOT_GRANTED','startCondition':'BLOCKED','productionWorker':'HOLD'})
(dest/'evidence-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for item in archives: print(json.dumps({k:v for k,v in item.items() if k not in ['files','githubArtifact']},ensure_ascii=False))
