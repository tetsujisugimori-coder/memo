# Independent local evidence review

Scope: final diagnostic harness commit caf3f697598c606df850cfd9fc94de5b7c704777 and first six completed local trials. No source edits or additional browser trials performed. Later-running trials excluded from this report.

## Harness

The workflow now allows 45 minutes, exceeding 12 × 180 seconds (36 minutes) plus setup margin. It pins both subject checkout SHAs. Before each trial the controller compares six protected files byte-for-byte against git show of the requested commit; afterward it compares their hashes again. All planned trials are written up front as not_started, and attempted trials transition separately to starting, passed, test_failure, startup_failure, controller_timeout, or source_verification_failure. Source mismatch aborts further execution. Runtime metadata includes Node/OS/browser manifest; run start/end and browser version are recorded. Reload captures preserve prior document events. Product timers, RAF, storage writers, and assertions are not patched.

Detailed focus wrapping catches only its own record failure; Reflect.apply(originalFocus, this, args) lies outside that catch, so native focus errors/results remain unchanged. The detailed wait wrapper logs then rethrows original wait errors. Observation overhead remains a limitation. Six protected files are verified, not every source file against Git; the complete pre-run manifest supplies broader recorded identity.

## First-repetition outcomes

- 1-main-webkit-none: passed; verified source=True; protected files unchanged=True; 2026-11-11T04:37:19.956Z to 2026-11-11T04:37:46.478Z.
- 1-main-webkit-light: passed; verified source=True; protected files unchanged=True; 2026-11-11T04:37:46.895Z to 2026-11-11T04:38:12.957Z.
- 1-main-webkit-detailed: passed; verified source=True; protected files unchanged=True; 2026-11-11T04:38:13.442Z to 2026-11-11T04:38:41.755Z.
- 1-pr-webkit-none: passed; verified source=True; protected files unchanged=True; 2026-11-11T04:38:42.252Z to 2026-11-11T04:39:09.289Z.
- 1-pr-webkit-light: passed; verified source=True; protected files unchanged=True; 2026-11-11T04:39:09.733Z to 2026-11-11T04:39:35.889Z.
- 1-pr-webkit-detailed: passed; verified source=True; protected files unchanged=True; 2026-11-11T04:39:36.418Z to 2026-11-11T04:40:03.000Z.

Local runtime: Debian 13, Node v24.22.1, Playwright 1.62.1, WebKit 26.5, custom executable launcher recorded in each run.json. This differs from original Ubuntu/Node22; CI comparison must be considered separately.

## Target sequence in page-1-before-reload-1.json

Times below are document-local performance.now milliseconds, not cross-process timestamps. Each instrumented capture reports dropped=0. Light files contain 360 events; detailed files contain 654.

- Main/light: prior move fallback focus 8277; numeric input focus 8304; Infinity beforeinput 8307 and input 8309 on node52; next click 8357; rejected move refocuses same Infinity node52 at 8358.
- Main/detailed: prior move focus-call/focusin 9409, stack app.js:11277; numeric focus 9429; Infinity beforeinput9430/input9431 on node162; next click9499; rejection focus-call9500 on same node162, stack handleChartEditorAction app.js:11266.
- PR/light: prior fallback focus8300; numeric focus8318; Infinity beforeinput8321/input8326 on node52; click8421; same Infinity node52 refocused8421.
- PR/detailed: prior focus-call8614/focusin8615, stack app.js:11375; numeric focus8622; Infinity beforeinput8623/input8625 on node162; click8680; same Infinity node162 refocused8680, stack handleChartEditorAction app.js:11364.

In every available instrumented run, the prior asynchronous focus completes BEFORE fill focuses the value input. Infinity then reaches the intended field, survives until click, and is rejected using the same node. In detailed files the intervening childList records affect status text, not replacement of the editor input. The target wait resolves and the unchanged test assertions subsequently pass. Successful-only evidence supports correct validation under this observed ordering; it does not reproduce the proposed adverse ordering.

## Comparison with original failure

The original failure log reports January/March/February order with correspondingly moved series and success status for moving February, while the target focus-plus-error predicate timed out. It did not capture the original input event, input value before click, node identity, active focus, or exact target wait-start. The successful local captures therefore cannot establish what happened in that failing run.

The deferred-focus interference hypothesis remains plausible from code ordering, not confirmed. These runs neither show Infinity being lost nor demonstrate a rebuild discarding it. They do not establish PR448 causation, disprove a rare race, or justify weakening the original assertion. No repair or root-cause claim is supported by this subset.
